/**
 * Decodes a Google ID token (JWT) just enough to read the public claims —
 * name, email, picture. This does NOT verify the token's signature; it's
 * fine for greeting the person on this static page. If you later need to
 * trust this identity server-side (to create a session, write to a
 * database, etc.), verify the token on your server first — don't trust
 * anything decoded in the browser.
 */
function decodeJwt(token) {
  const payload = token.split('.')[1];
  const json = atob(payload.replace(/-/g, '+').replace(/_/g, '/'));
  return JSON.parse(decodeURIComponent(escape(json)));
}

function handleCredential(response) {
  const status = document.getElementById('signin-status');
  try {
    const claims = decodeJwt(response.credential);
    status.hidden = false;
    status.textContent = `Signed in as ${claims.name || claims.email}.`;
  } catch {
    status.hidden = false;
    status.textContent = 'Could not read that sign-in response — try again.';
  }
}

window.addEventListener('load', () => {
  const clientId = window.GOOGLE_CLIENT_ID;
  const slot = document.getElementById('g_id_signin');
  if (!clientId) {
    slot.textContent = 'Set GOOGLE_CLIENT_ID to enable sign-in.';
    slot.style.color = 'var(--text-dim)';
    slot.style.fontSize = '14px';
    return;
  }
  google.accounts.id.initialize({
    client_id: clientId,
    callback: handleCredential
  });
  google.accounts.id.renderButton(slot, {
    theme: 'filled_black',
    size: 'large',
    shape: 'pill',
    text: 'signin_with'
  });
});
