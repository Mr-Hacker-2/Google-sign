import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

// The Google OAuth client ID is public by design (it identifies the app,
// not a secret), but keeping it in an env var means you don't have to edit
// code to swap it — just change GOOGLE_CLIENT_ID in Render's dashboard.
app.get('/config.js', (req, res) => {
  const clientId = process.env.GOOGLE_CLIENT_ID || '';
  res.type('application/javascript').send(`window.GOOGLE_CLIENT_ID = ${JSON.stringify(clientId)};`);
});

app.use(express.static(path.join(__dirname, 'public')));

app.listen(PORT, () => {
  console.log(`Viora site listening on port ${PORT}`);
});
