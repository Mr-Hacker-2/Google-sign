# Viora site

A small homepage for Viora with a "Sign in with Google" button, built to
deploy on Render.

## What's here

- `public/index.html`, `public/styles.css`, `public/app.js` — the page
- `public/privacy.html` — placeholder privacy page (replace the text before
  going live — Google's OAuth consent screen asks for a link to one)
- `server.js` — a tiny Express server that serves the `public/` folder and
  one extra route, `/config.js`, which hands the page your Google client ID
  from an environment variable
- `render.yaml` — lets Render auto-configure the service (Blueprint deploy)

## 1. Get a Google OAuth client ID

The extension already has a client ID (in `src/lib/access.js`), but that one
was very likely created as a **Chrome extension** OAuth client, which only
allows `chrome-extension://...` and `https://<id>.chromiumapp.org/` as
origins — it will not work from a normal website. For this page, create a
separate client:

1. [Google Cloud Console → Credentials](https://console.cloud.google.com/apis/credentials),
   same project as the extension (or a new one).
2. **Create credentials → OAuth client ID → Web application.**
3. Under **Authorized JavaScript origins**, add your Render URL once you
   have it, e.g. `https://viora-site.onrender.com` (and `http://localhost:3000`
   for testing locally).
4. You don't need a redirect URI for this page — Google Identity Services
   uses a popup/One Tap flow, not a redirect.
5. Copy the client ID (looks like `123...-abc...apps.googleusercontent.com`).

## 2. Deploy to Render

**Option A — Blueprint (uses `render.yaml`):**
1. Push this folder to a GitHub repo.
2. In Render: **New → Blueprint**, point it at the repo.
3. Render reads `render.yaml` and asks you to fill in `GOOGLE_CLIENT_ID` —
   paste the client ID from step 1.

**Option B — manual:**
1. **New → Web Service**, point it at the repo (or upload the folder).
2. Build command: `npm install`. Start command: `npm start`.
3. Under **Environment**, add `GOOGLE_CLIENT_ID` = your client ID.
4. Deploy.

Once it's live, go back to the OAuth client in Google Cloud Console and make
sure the Render URL you were given is in **Authorized JavaScript origins** —
Google won't show the sign-in button on an origin it doesn't recognize.

## 3. Test locally (optional)

```
npm install
GOOGLE_CLIENT_ID=your-client-id.apps.googleusercontent.com npm start
```

Open http://localhost:3000 — add that exact origin to the OAuth client
first, or the button will fail silently.

## Note on what this page does and doesn't do

Clicking "Sign in with Google" gets you a Google identity token in the
browser and greets you by name — enough for a homepage demo, and enough to
serve as the public homepage Google's OAuth consent screen asks for. It
does **not** create a session, store accounts, or talk to Backblaze — that's
handled separately, inside the extension (`src/lib/cloud.js`). If you later
want this website itself to log people into a real account, the token needs
to be verified server-side before you trust it (see the comment in
`public/app.js`).
